var keys = {
  clientID:"230755439544-vqgqbq2ng7dvnt26ac6a52fq3ri7b7bc.apps.googleusercontent.com","project_id":"dashboard-iim-indore","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://accounts.google.com/o/oauth2/token","auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs",
  client_secret:"AxtqABYQaJj1bciP4M71_3aW",
  cookieKey: 'iimindoreerpmadebysrijanreddy'
}
module.exports = {
    keys
}
